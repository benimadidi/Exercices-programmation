import tkinter as tk
from tkinter import font
import random
import time
import threading
from pygame import mixer

class Particle:
    def __init__(self, canvas, x, y, dx, dy, color, lifetime):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
        self.color = color
        self.lifetime = lifetime
        self.shape = canvas.create_oval(x, y, x + 3, y + 3, fill=color, outline="")

    def update(self):
        self.lifetime -= 1
        self.canvas.move(self.shape, self.dx, self.dy)
        if self.lifetime <= 0:
            self.canvas.delete(self.shape)
            return False
        return True

class Firework:
    def __init__(self, canvas, x, y, color):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.color = color
        self.particles = []

    def explode(self):
        for _ in range(100):
            dx = random.uniform(-4, 4)
            dy = random.uniform(-4, 4)
            lifetime = random.randint(20, 60)
            particle = Particle(self.canvas, self.x, self.y, dx, dy, self.color, lifetime)
            self.particles.append(particle)

    def update_particles(self):
        self.particles = [p for p in self.particles if p.update()]
        return bool(self.particles)

class Star:
    def __init__(self, canvas, x, y):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.shape = canvas.create_oval(x, y, x + 2, y + 2, fill="white", outline="")
        self.dx = random.uniform(-1, 1)
        self.dy = random.uniform(2, 4)

    def update(self):
        self.canvas.move(self.shape, self.dx, self.dy)
        coords = self.canvas.coords(self.shape)
        if coords[1] > self.canvas.winfo_height():
            self.canvas.delete(self.shape)
            return False
        return True

class Confetti:
    def __init__(self, canvas):
        self.canvas = canvas
        self.particles = []

    def create_particles(self):
        colors = ["red", "blue", "green", "yellow", "purple", "orange"]
        for _ in range(200):
            x = random.randint(0, self.canvas.winfo_width())
            y = random.randint(0, self.canvas.winfo_height())
            color = random.choice(colors)
            particle = Particle(self.canvas, x, y, 0, 0, color, random.randint(50, 100))
            self.particles.append(particle)

    def update_particles(self):
        self.particles = [p for p in self.particles if p.update()]
        return bool(self.particles)

class AnimatedGreeting:
    def __init__(self, root):
        self.root = root
        self.root.title("Bonne Année 2025")
        self.root.geometry("1000x700")
        self.canvas = tk.Canvas(root, width=1000, height=700, bg="black")
        self.canvas.pack()

        self.label = tk.Label(root, text="", font=("Helvetica", 36, "bold"), fg="white", bg="black")
        self.label.place(relx=0.5, rely=0.1, anchor="center")

        self.greeting_text = "Bonne Année 2025!"
        self.index = 0
        self.animate_text()
        self.fireworks = []
        self.stars = []
        self.confetti = Confetti(self.canvas)
        self.music_playing = False

        mixer.init()
        mixer.music.load("happy_new_year.mp3")

    def animate_text(self):
        if self.index <= len(self.greeting_text):
            current_text = self.greeting_text[:self.index]
            self.label.config(text=current_text)
            self.index += 1
            self.root.after(200, self.animate_text)
        else:
            self.label.config(font=("Helvetica", 42, "bold"))
            self.label.after(500, self.scintillate_text)
            self.create_fireworks()
            self.create_stars()
            self.create_confetti()
            if not self.music_playing:
                mixer.music.play()
                self.music_playing = True

    def scintillate_text(self):
        colors = ["white", "yellow", "cyan", "magenta"]
        current_color = random.choice(colors)
        self.label.config(fg=current_color)
        self.root.after(500, self.scintillate_text)

    def create_fireworks(self):
        colors = ["red", "blue", "green", "yellow", "purple", "orange"]
        for _ in range(15):
            x = random.randint(100, 900)
            y = random.randint(100, 600)
            color = random.choice(colors)
            firework = Firework(self.canvas, x, y, color)
            firework.explode()
            self.fireworks.append(firework)
        self.update_fireworks()

    def update_fireworks(self):
        self.fireworks = [fw for fw in self.fireworks if fw.update_particles()]
        if self.fireworks:
            self.root.after(50, self.update_fireworks)
        else:
            self.root.after(1000, self.create_fireworks)

    def create_stars(self):
        for _ in range(50):
            x = random.randint(0, self.canvas.winfo_width())
            y = random.randint(0, self.canvas.winfo_height() // 2)
            star = Star(self.canvas, x, y)
            self.stars.append(star)
        self.update_stars()

    def update_stars(self):
        self.stars = [star for star in self.stars if star.update()]
        self.root.after(100, self.update_stars)

    def create_confetti(self):
        self.confetti.create_particles()
        self.update_confetti()

    def update_confetti(self):
        if self.confetti.update_particles():
            self.root.after(50, self.update_confetti)

if __name__ == "__main__":
    root = tk.Tk()
    app = AnimatedGreeting(root)
    root.mainloop()
